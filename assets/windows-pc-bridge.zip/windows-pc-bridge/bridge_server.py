#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
피클 PC 브릿지 (Pickle PC Bridge) v1.0
=================================================================
갤럭시 태블릿/폰의 'PC 컨트롤 대시보드'가 이 PC를 제어할 수 있게 해 주는
가벼운 로컬 서버입니다. 인터넷에 공개되지 않고, 같은 Wi-Fi(또는 Tailscale)
안에서만 접속됩니다. 모든 API는 config.json 의 보안 토큰이 있어야 동작합니다.

  실행            : start_bridge.bat 더블클릭 (또는 python bridge_server.py)
  기본 포트        : 8765
  인증 헤더        : X-Dashboard-Token: <config.json 의 token>

  GET  /api/ping       서버 살아있는지 확인 (토큰 불필요)
  GET  /api/status     CPU · RAM · 배터리 · PC 이름
  GET  /api/capture    현재 PC 화면을 PNG 로 캡처 (base64)
  POST /api/launch     {"app": "chrome"} 화이트리스트 앱 실행
  POST /api/clipboard  {"text": "..."} PC 클립보드에 복사

개인정보(이름·전화·주소·고정 토큰)는 코드에 넣지 않았습니다.
토큰은 이 PC에서 처음 실행할 때 자동으로 만들어져 config.json 에만 저장됩니다.
"""
from __future__ import annotations

import base64
import json
import os
import platform
import secrets
import subprocess
import sys
import tempfile
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

VERSION = "1.0"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
IS_WIN = platform.system() == "Windows"
MAX_BODY = 2 * 1024 * 1024  # 2MB

# ---------------- 선택 라이브러리 ----------------
try:
    import psutil  # CPU / RAM / 배터리
except Exception:
    psutil = None
try:
    from PIL import ImageGrab  # 화면 캡처 (없으면 PowerShell 로 대체)
except Exception:
    ImageGrab = None
try:
    import pyperclip  # 클립보드 (없으면 PowerShell 로 대체)
except Exception:
    pyperclip = None


# =================================================================
#  설정 파일
# =================================================================
DEFAULT_WEB_APPS = {
    "youtube": "https://www.youtube.com",
    "chatgpt": "https://chatgpt.com",
    "claude": "https://claude.ai",
    "notion": "https://www.notion.so",
    "notion_calendar": "https://www.notion.so/calendar",
    "pickle": "",
}


def save_config(cfg: dict) -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def load_config() -> dict:
    cfg = {}
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            if not isinstance(cfg, dict):
                cfg = {}
        except Exception as e:
            print("  ! config.json 을 읽지 못했습니다 (%s) — 새로 만듭니다." % e)
            cfg = {}

    changed = False
    token = cfg.get("token")
    if not isinstance(token, str) or len(token) < 8:
        cfg["token"] = secrets.token_urlsafe(18)  # 첫 실행 시 자동 생성
        changed = True
    if not isinstance(cfg.get("port"), int):
        cfg["port"] = 8765
        changed = True
    if not isinstance(cfg.get("bind"), str) or not cfg["bind"]:
        cfg["bind"] = "0.0.0.0"
        changed = True
    web = cfg.get("web_apps")
    if not isinstance(web, dict):
        web = {}
    for k, v in DEFAULT_WEB_APPS.items():
        web.setdefault(k, v)
    cfg["web_apps"] = web
    if changed:
        save_config(cfg)
    return cfg


def reset_token() -> dict:
    cfg = load_config()
    cfg["token"] = secrets.token_urlsafe(18)
    save_config(cfg)
    return cfg


# =================================================================
#  시스템 지표
# =================================================================
def _prime_psutil() -> None:
    if psutil is not None:
        try:
            psutil.cpu_percent(interval=None)  # 첫 호출은 0.0 이므로 미리 한 번
        except Exception:
            pass


def sys_status(cfg: dict) -> dict:
    out = {
        "ok": True,
        "app": "pickle-pc-bridge",
        "version": VERSION,
        "host": platform.node() or "",
        "os": platform.system() + " " + platform.release(),
        "server_time": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "cpu": {"percent": None, "cores": None},
        "ram": {"percent": None, "used_gb": None, "total_gb": None},
        "battery": None,
        "uptime_s": None,
    }
    if psutil is not None:
        try:
            vm = psutil.virtual_memory()
            out["ram"] = {
                "percent": round(vm.percent, 1),
                "used_gb": round((vm.total - vm.available) / (1024 ** 3), 1),
                "total_gb": round(vm.total / (1024 ** 3), 1),
            }
        except Exception:
            pass
        try:
            out["cpu"] = {
                "percent": round(psutil.cpu_percent(interval=0.1), 1),
                "cores": psutil.cpu_count(logical=True),
            }
        except Exception:
            pass
        try:
            bat = psutil.sensors_battery()
            if bat is not None:
                out["battery"] = {
                    "percent": round(float(bat.percent), 1),
                    "plugged": bool(bat.power_plugged),
                }
        except Exception:
            pass
        try:
            out["uptime_s"] = int(time.time() - psutil.boot_time())
        except Exception:
            pass
    return out


# =================================================================
#  화면 캡처
# =================================================================
def _capture_with_pil() -> bytes:
    if ImageGrab is None:
        raise RuntimeError("pillow 없음")
    try:
        img = ImageGrab.grab(all_screens=True)  # 다중 모니터 전체
    except TypeError:
        img = ImageGrab.grab()
    from io import BytesIO
    buf = BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def _capture_with_powershell() -> bytes:
    ps = (
        "Add-Type -AssemblyName System.Windows.Forms,System.Drawing;"
        "$b=[System.Windows.Forms.SystemInformation]::VirtualScreen;"
        "$bit=New-Object System.Drawing.Bitmap $b.Width,$b.Height;"
        "$g=[System.Drawing.Graphics]::FromImage($bit);"
        "$g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size);"
        "$ms=New-Object System.IO.MemoryStream;"
        "$bit.Save($ms,[System.Drawing.Imaging.ImageFormat]::Png);"
        "[Convert]::ToBase64String($ms.ToArray())"
    )
    p = subprocess.run(
        ["powershell", "-NoProfile", "-STA", "-Command", ps],
        capture_output=True, timeout=30,
    )
    txt = p.stdout.decode("ascii", "ignore").strip()
    if p.returncode != 0 or not txt:
        raise RuntimeError((p.stderr.decode("utf-8", "ignore") or "powershell 캡처 실패")[:200])
    return base64.b64decode(txt)


def capture_png() -> dict:
    if not IS_WIN:
        return {"ok": False, "error": "화면 캡처는 Windows 에서만 동작합니다 (지금 OS: %s)" % platform.system()}
    errors = []
    data = None
    try:
        data = _capture_with_pil()
    except Exception as e:
        errors.append(str(e))
        try:
            data = _capture_with_powershell()
        except Exception as e2:
            errors.append(str(e2))
    if not data:
        return {"ok": False, "error": " / ".join([e for e in errors if e])[:300]}
    import struct
    width = height = 0
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        width, height = struct.unpack(">II", data[16:24])
    return {
        "ok": True,
        "image": "data:image/png;base64," + base64.b64encode(data).decode("ascii"),
        "width": width,
        "height": height,
        "bytes": len(data),
    }


# =================================================================
#  앱 실행 (화이트리스트만)
# =================================================================
def _reg_app_path(exe_name: str) -> str | None:
    if not IS_WIN:
        return None
    try:
        import winreg
    except Exception:
        return None
    key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\\" + exe_name
    for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            with winreg.OpenKey(root, key) as k:
                path, _ = winreg.QueryValueEx(k, "")
                path = str(path).strip('"')
                if path and os.path.exists(path):
                    return path
        except OSError:
            continue
    return None


def _first_existing(*paths: str) -> str | None:
    for p in paths:
        if p and os.path.exists(p):
            return p
    return None


def _find_app(app_id: str) -> str | None:
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    lad = os.environ.get("LOCALAPPDATA", "")
    apd = os.environ.get("APPDATA", "")
    if app_id == "chrome":
        return _first_existing(
            os.path.join(pf, r"Google\Chrome\Application\chrome.exe"),
            os.path.join(pf86, r"Google\Chrome\Application\chrome.exe"),
            os.path.join(lad, r"Google\Chrome\Application\chrome.exe"),
        ) or _reg_app_path("chrome.exe")
    if app_id == "kakaotalk":
        return _first_existing(
            os.path.join(pf86, r"Kakao\KakaoTalk\KakaoTalk.exe"),
            os.path.join(pf, r"Kakao\KakaoTalk\KakaoTalk.exe"),
            os.path.join(lad, r"Kakao\KakaoTalk\KakaoTalk.exe"),
        ) or _reg_app_path("KakaoTalk.exe")
    if app_id == "notion":
        return _first_existing(
            os.path.join(lad, r"Programs\Notion\Notion.exe"),
            os.path.join(pf, r"Notion\Notion.exe"),
            os.path.join(pf86, r"Notion\Notion.exe"),
        ) or _reg_app_path("Notion.exe")
    if app_id == "zoom":
        return _first_existing(
            os.path.join(apd, r"Zoom\bin\Zoom.exe"),
            os.path.join(pf, r"Zoom\bin\Zoom.exe"),
            os.path.join(pf86, r"Zoom\bin\Zoom.exe"),
        ) or _reg_app_path("Zoom.exe")
    return None


def _start(exe: str, *args: str) -> None:
    if not IS_WIN:
        raise RuntimeError("Windows 전용")
    if args:
        subprocess.Popen([exe, *args], close_fds=True)
    else:
        os.startfile(exe)  # type: ignore[attr-defined]


def empty_recycle_bin() -> dict:
    if not IS_WIN:
        return {"ok": False, "error": "휴지통 비우기는 Windows 에서만 동작합니다"}
    import ctypes
    SHERB_NOCONFIRMATION, SHERB_NOPROGRESSUI, SHERB_NOSOUND = 0x1, 0x2, 0x4
    flags = SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND
    try:
        rc = ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, flags)
    except Exception as e:
        return {"ok": False, "error": "휴지통 비우기 실패: %s" % e}
    # 0 = 성공, 0x8000FFFF(E_UNEXPECTED) = 이미 비어 있음
    if rc == 0:
        return {"ok": True, "via": "휴지통 비움"}
    if rc & 0xFFFFFFFF == 0x8000FFFF:
        return {"ok": True, "via": "휴지통이 이미 비어 있음"}
    return {"ok": False, "error": "휴지통 비우기 실패 (코드 %s)" % rc}


def launch_app(app_id: str, cfg: dict) -> dict:
    app_id = (app_id or "").strip().lower()
    web = cfg.get("web_apps", {}) or {}

    if app_id in ("settings", "설정"):
        if not IS_WIN:
            return {"ok": False, "error": "Windows 전용 기능입니다"}
        os.startfile("ms-settings:")  # type: ignore[attr-defined]
        return {"ok": True, "via": "Windows 설정"}

    if app_id in ("explorer", "탐색기"):
        if not IS_WIN:
            return {"ok": False, "error": "Windows 전용 기능입니다"}
        _start("explorer.exe")
        return {"ok": True, "via": "탐색기"}

    if app_id in ("recycle", "recycle_bin", "trash", "휴지통"):
        return empty_recycle_bin()

    if app_id in ("chrome", "kakaotalk", "zoom"):
        exe = _find_app(app_id)
        if not exe:
            return {"ok": False, "error": "이 PC에서 프로그램을 찾지 못했습니다. 설치되어 있는지 확인해 주세요."}
        _start(exe)
        return {"ok": True, "via": os.path.basename(exe)}

    if app_id == "notion":
        exe = _find_app("notion")
        if exe:
            _start(exe)
            return {"ok": True, "via": "Notion 앱"}
        url = web.get("notion") or "https://www.notion.so"
        webbrowser.open(url)
        return {"ok": True, "via": "브라우저 · " + url}

    if app_id in ("youtube", "chatgpt", "claude", "notion_calendar", "pickle"):
        url = (web.get(app_id) or "").strip()
        if not url:
            return {"ok": False, "error": "config.json 의 web_apps.%s 에 주소를 넣어 주세요" % app_id}
        webbrowser.open(url)
        return {"ok": True, "via": "브라우저 · " + url}

    return {"ok": False, "error": "허용되지 않은 앱입니다: %s" % app_id}


# =================================================================
#  클립보드
# =================================================================
def set_clipboard(text: str) -> dict:
    if pyperclip is not None:
        try:
            pyperclip.copy(text)
            return {"ok": True, "via": "pyperclip"}
        except Exception:
            pass
    if IS_WIN:
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(suffix=".txt")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(text)
            ps = (
                "Add-Type -AssemblyName System.Windows.Forms;"
                "[System.Windows.Forms.Clipboard]::SetText("
                "[System.IO.File]::ReadAllText('%s',[System.Text.Encoding]::UTF8))" % tmp.replace("'", "''")
            )
            p = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps],
                               capture_output=True, timeout=20)
            if p.returncode == 0:
                return {"ok": True, "via": "PowerShell"}
            msg = (p.stderr.decode("utf-8", "ignore") or "").strip()[:200]
            return {"ok": False, "error": "클립보드 복사 실패 " + msg}
        except Exception as e:
            return {"ok": False, "error": "클립보드 복사 실패: %s" % e}
        finally:
            if tmp and os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except Exception:
                    pass
    return {"ok": False, "error": "pyperclip 이 필요합니다: pip install pyperclip"}


# =================================================================
#  HTTP 핸들러
# =================================================================
INFO_PAGE = """<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>피클 PC 브릿지</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0a0a0b;color:#eee;
font-family:-apple-system,'Malgun Gothic','Noto Sans KR',sans-serif}
.box{max-width:560px;padding:28px;border:1px solid #2b2b2d;border-radius:18px;background:#171718}
h1{margin:0 0 6px;font-size:19px}p{margin:0 0 10px;color:#a0a0a5;font-size:13px;line-height:1.7}
b{color:#eaeaea}.ok{color:#4ade80}code{background:#101011;padding:2px 6px;border-radius:6px;font-size:12px}</style>
</head><body><div class="box">
<h1>🖥️ 피클 PC 브릿지 <span class="ok">● 실행 중</span></h1>
<p>이 PC가 대시보드의 명령을 받을 준비가 됐습니다. 주소 <b>%(url)s</b> · 버전 %(ver)s</p>
<p>대시보드에서 <b>연결 설정</b>을 열고 위 주소와 <code>config.json</code> 의 <b>token</b> 값을 넣으세요.</p>
<p>이 화면을 닫아도 서버는 계속 실행됩니다. 서버를 멈추려면 검은 콘솔 창에서 <b>Ctrl + C</b> 를 누르거나 창을 닫으세요.</p>
</div></body></html>"""


class BridgeHandler(BaseHTTPRequestHandler):
    server_version = "PicklePCBridge/" + VERSION
    protocol_version = "HTTP/1.1"
    cfg: dict = {}

    # ---------- 공통 ----------
    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "X-Dashboard-Token, Content-Type")
        self.send_header("Access-Control-Max-Age", "86400")

    def _send(self, code: int, payload=None, *, ctype="application/json; charset=utf-8", body: bytes | None = None):
        if body is None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _json(self, code: int, obj: dict):
        self._send(code, obj)

    def _authorized(self) -> bool:
        token = str(self.cfg.get("token", ""))
        got = self.headers.get("X-Dashboard-Token") or ""
        if not got:
            q = parse_qs(urlparse(self.path).query)
            got = (q.get("token") or [""])[0]
        return bool(token) and secrets.compare_digest(str(got), token)

    def _need_auth(self) -> bool:
        if self._authorized():
            return False
        self._json(401, {"ok": False, "error": "보안 토큰이 필요합니다. 대시보드 연결 설정에 config.json 의 token 을 넣어 주세요."})
        return True

    def _read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            return {}
        if length > MAX_BODY:
            raise ValueError("내용이 너무 큽니다")
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            raise ValueError("JSON 형식이 아닙니다")
        return data if isinstance(data, dict) else {}

    def log_message(self, fmt, *args):  # 폴링 로그로 콘솔이 넘치지 않게
        pass

    def log_request(self, code="-", size="-"):
        path = urlparse(self.path).path
        if path in ("/api/status", "/api/ping", "/favicon.ico"):
            return
        try:
            code_i = int(code)
        except Exception:
            code_i = 0
        mark = "!" if code_i >= 400 else "·"
        print("   %s %-6s %-18s %s" % (time.strftime("%H:%M:%S"), self.command, path, code_i))

    # ---------- OPTIONS ----------
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    # ---------- GET ----------
    def do_GET(self):
        path = urlparse(self.path).path.rstrip("/") or "/"

        if path == "/api/ping":
            return self._json(200, {"ok": True, "app": "pickle-pc-bridge", "version": VERSION,
                                    "auth": "X-Dashboard-Token"})

        if path in ("/", "/index.html"):
            port = self.cfg.get("port", 8765)
            html = INFO_PAGE % {"url": "http://localhost:%s" % port, "ver": VERSION}
            return self._send(200, None, ctype="text/html; charset=utf-8", body=html.encode("utf-8"))

        if path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        if path == "/api/status":
            if self._need_auth():
                return
            return self._json(200, sys_status(self.cfg))

        if path == "/api/capture":
            if self._need_auth():
                return
            return self._json(200, capture_png())

        self._json(404, {"ok": False, "error": "없는 주소입니다: %s" % path})

    # ---------- POST ----------
    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/") or "/"
        try:
            data = self._read_json()
        except ValueError as e:
            return self._json(400, {"ok": False, "error": str(e)})

        if path not in ("/api/launch", "/api/clipboard"):
            return self._json(404, {"ok": False, "error": "없는 주소입니다: %s" % path})

        if self._need_auth():
            return

        if path == "/api/launch":
            app_id = str(data.get("app") or "")
            if not app_id:
                return self._json(400, {"ok": False, "error": "app 값을 지정해 주세요"})
            try:
                result = launch_app(app_id, self.cfg)
            except Exception as e:
                result = {"ok": False, "error": "실행 실패: %s" % e}
            return self._json(200 if result.get("ok") else 400, result)

        # /api/clipboard
        text = data.get("text")
        if not isinstance(text, str) or not text:
            return self._json(400, {"ok": False, "error": "text 값을 지정해 주세요"})
        if len(text) > 20000:
            return self._json(400, {"ok": False, "error": "text 가 너무 깁니다(2만 자 이하)"})
        result = set_clipboard(text)
        return self._json(200 if result.get("ok") else 400, result)


# =================================================================
#  시작
# =================================================================
def local_ips() -> list:
    import socket
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ips.add(s.getsockname()[0])
        finally:
            s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and not ip.startswith("169.254."):
                ips.add(ip)
    except Exception:
        pass
    return sorted(ips)


def banner(cfg: dict, port: int) -> None:
    line = "  " + "─" * 66
    print()
    print("  [ 피클 PC 브릿지 v%s ]  이 창을 닫으면 서버가 꺼집니다" % VERSION)
    print(line)
    print("  보안 토큰 : %s" % cfg["token"])
    print("  이 PC에서   : http://localhost:%d" % port)
    for ip in local_ips():
        print("  태블릿/폰에서: http://%s:%d" % (ip, port))
    print(line)
    print("  대시보드    : https://gene4517-bot.github.io/ai-office/dashboard/")
    print("  연결 방법   : 대시보드 오른쪽 위 ⚙ → 위 주소와 보안 토큰을 붙여 넣고 [저장하고 연결]")
    print(line)
    if psutil is None:
        print("  ! psutil 이 없어 CPU/RAM/배터리를 못 읽습니다 → start_bridge.bat 을 쓰면 자동 설치됩니다.")
    if not IS_WIN:
        print("  ! 지금 OS 는 %s 입니다. 화면 캡처·앱 실행·휴지통은 Windows 에서만 동작합니다." % platform.system())
    print("  종료하려면 Ctrl + C")
    print(line)
    print()


def main() -> int:
    args = sys.argv[1:]
    if "--new-token" in args:
        cfg = reset_token()
        print("  새 보안 토큰을 만들었습니다. 대시보드 연결 설정에도 새 토큰을 넣어 주세요.")
    else:
        cfg = load_config()

    port = cfg.get("port", 8765)
    bind = cfg.get("bind", "0.0.0.0")
    for i, a in enumerate(args):
        if a == "--port" and i + 1 < len(args):
            port = int(args[i + 1])
        if a == "--bind" and i + 1 < len(args):
            bind = args[i + 1]

    _prime_psutil()
    time.sleep(0.2)
    _prime_psutil()

    BridgeHandler.cfg = cfg
    try:
        httpd = ThreadingHTTPServer((bind, port), BridgeHandler)
    except OSError as e:
        print()
        print("  ❌ %d 번 포트를 열 수 없습니다: %s" % (port, e))
        print("     이미 브릿지가 실행 중인지 확인하세요. (창을 두 개 켠 경우)")
        print("     포트를 바꾸려면 config.json 의 port 값을 고치세요.")
        return 1

    httpd.daemon_threads = True
    banner(cfg, port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  브릿지를 종료합니다. 수고하셨어요!")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
