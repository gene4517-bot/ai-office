@echo off
chcp 65001 >nul 2>nul
title 피클 PC 브릿지
cd /d "%~dp0"

echo.
echo   ============================================================
echo    피클 PC 브릿지  (Pickle PC Bridge)
echo    태블릿^/폰 대시보드에서 이 PC를 제어하는 작은 서버입니다.
echo   ============================================================
echo.

rem ---------- 1. 파이썬 찾기 ----------
set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo   [문제] 파이썬이 설치되어 있지 않습니다.
  echo.
  echo    1) 아래 주소에서 Python 을 설치하세요.
  echo       설치 화면 맨 아래 "Add python.exe to PATH" 를 꼭 체크하세요.
  echo       https://www.python.org/downloads/
  echo    2) 설치가 끝나면 이 파일을 다시 더블클릭하세요.
  echo.
  start "" https://www.python.org/downloads/
  pause
  exit /b 1
)

echo   [1/3] 파이썬 확인 완료.
%PY% --version
echo.

rem ---------- 2. 필요한 부품 설치 ----------
echo   [2/3] 필요한 부품(psutil, pillow, pyperclip)을 확인합니다.
echo         처음 한 번만 시간이 조금 걸립니다.
%PY% -m pip install --quiet --disable-pip-version-check psutil pillow pyperclip
if errorlevel 1 (
  echo         ! 부품 설치에 실패했습니다. 인터넷 연결을 확인하세요.
  echo           (설치가 안 되어도 기본 기능은 동작합니다. 화면 캡처만 안 될 수 있습니다.)
)
echo         준비 완료.
echo.

rem ---------- 3. 서버 실행 ----------
echo   [3/3] 서버를 시작합니다.
echo.
echo   * 처음 실행하면 "Windows 보안 경고" 창이 뜰 수 있습니다.
echo     [개인 네트워크] 에 체크하고 [액세스 허용] 을 누르세요.
echo     (같은 Wi-Fi 의 태블릿^/폰이 접속하려면 꼭 필요합니다)
echo.

%PY% "%~dp0bridge_server.py" %*

echo.
echo   브릿지가 종료되었습니다. 창을 닫으려면 아무 키나 누르세요.
pause >nul
